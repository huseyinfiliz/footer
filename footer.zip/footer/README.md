# footer links
Add fully compatible and responsive modern footer for flarum
