// admin.js
export * from './src/admin';