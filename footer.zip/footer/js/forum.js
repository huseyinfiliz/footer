// forum.js
export * from './src/forum';