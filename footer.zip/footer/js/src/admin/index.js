import app from 'flarum/admin/app';

app.initializers.add('huseyinfiliz-footer', () => {
  console.log('[huseyinfiliz/footer] Hello, forum and admin!');
});