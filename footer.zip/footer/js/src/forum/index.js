import app from 'flarum/admin/app';

// We provide our extension code in the form of an "initializer".
// This is a callback that will run after the core has booted.
app.initializers.add('huseyinfiliz-footer-console', function(app) {
  // Your Extension Code Here
  console.log("Footer is working!");
});